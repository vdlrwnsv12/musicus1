namespace MirrorGear.Mercury
{
	public interface IMercuryEventCallback
	{
		void OnEvent();
	}
}

