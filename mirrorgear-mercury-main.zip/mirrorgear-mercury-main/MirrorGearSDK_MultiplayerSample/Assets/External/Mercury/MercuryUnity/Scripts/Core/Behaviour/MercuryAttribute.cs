using System;

namespace MirrorGear.Mercury
{
	/// <summary>
	/// code : RPC
	/// string : methodName
	/// object[] : params
	/// </summary>
	public class MercuryRPC : Attribute
	{
	}
}
