using TMPro;
using UnityEngine;

public class SamplePlayer : MonoBehaviour
{
    public TMP_Text lbName;
}
